<div class="modal-quick-view modal fade" id="quick-view" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content" id="quick-view-modal">

        </div>
    </div>
</div>
