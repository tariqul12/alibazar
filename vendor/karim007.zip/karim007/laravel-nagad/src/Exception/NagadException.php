<?php

namespace Karim007\LaravelNagad\Exception;

use Exception;

class NagadException extends Exception
{

}
