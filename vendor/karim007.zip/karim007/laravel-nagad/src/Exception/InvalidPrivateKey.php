<?php


namespace Karim007\LaravelNagad\Exception;

use Exception;

class InvalidPrivateKey extends Exception
{

}
