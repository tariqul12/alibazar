<?php


namespace Karim007\LaravelNagad\Exception;

use Exception;

class InvalidPublicKey extends Exception
{

}
