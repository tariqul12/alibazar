<?php


namespace PortWallet\Exceptions;


class BadRequestException extends PortWalletException {}
