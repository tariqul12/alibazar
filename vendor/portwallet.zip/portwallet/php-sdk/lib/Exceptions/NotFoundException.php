<?php


namespace PortWallet\Exceptions;


class NotFoundException extends PortWalletException {}
