<?php


namespace PortWallet\Exceptions;


class InvalidArgumentException extends \InvalidArgumentException {}
