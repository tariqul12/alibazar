<?php


namespace PortWallet\Exceptions;


class UnauthorizedException extends PortWalletException {}
