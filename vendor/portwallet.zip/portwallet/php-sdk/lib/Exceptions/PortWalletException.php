<?php


namespace PortWallet\Exceptions;


class PortWalletException extends \Exception {}
