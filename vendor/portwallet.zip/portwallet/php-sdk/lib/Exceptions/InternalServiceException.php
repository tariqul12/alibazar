<?php


namespace PortWallet\Exceptions;


class InternalServiceException extends PortWalletException {}
