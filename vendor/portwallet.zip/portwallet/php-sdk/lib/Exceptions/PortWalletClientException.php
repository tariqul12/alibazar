<?php


namespace PortWallet\Exceptions;


class PortWalletClientException extends PortWalletException {}
